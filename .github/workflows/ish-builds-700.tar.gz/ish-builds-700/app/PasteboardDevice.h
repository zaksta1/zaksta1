// Pasteboard is implementation of /dev/clipboard device
extern struct dev_ops clipboard_dev;
