//
//  IconViewController.h
//  iSH
//
//  Created by Theodore Dubois on 12/13/19.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AltIconViewController : UIViewController <UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout>

@end

NS_ASSUME_NONNULL_END
