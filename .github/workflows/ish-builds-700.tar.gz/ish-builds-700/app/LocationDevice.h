//
//  LocationDevice.h
//  iSH
//
//  Created by Theodore Dubois on 10/20/19.
//

extern struct dev_ops location_dev;
