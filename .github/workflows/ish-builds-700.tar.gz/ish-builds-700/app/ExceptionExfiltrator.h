//
//  ExceptionExfiltrator.h
//  iSH
//
//  Created by Saagar Jha on 5/5/23.
//

#ifndef ExceptionExfiltrator_h
#define ExceptionExfiltrator_h

#import <Foundation/Foundation.h>

void iSHExceptionHandler(NSException *exception);

#endif /* ExceptionExfiltrator_h */
