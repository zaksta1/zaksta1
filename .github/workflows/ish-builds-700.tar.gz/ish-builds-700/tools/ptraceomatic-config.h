#define VVAR_PAGES 4
#define VDSO_PAGES 2
