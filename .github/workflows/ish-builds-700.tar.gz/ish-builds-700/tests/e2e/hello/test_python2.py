print 'Hello, Python 2!'
