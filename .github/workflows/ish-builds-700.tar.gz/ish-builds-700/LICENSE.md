iSH is licensed under the [GPLv3][]. The additional terms in LICENSE.IOS also apply.

Contributions made after commit 0e3a4144f93135c4fd618c8397d2cfd87194f69f are
additionally licensed under the [GPLv2][]. This is intended to allow linking
with GPLv2 licensed projects such as Linux and QEMU.

The following authors have agreed to relicense their past contributions under GPLv2:
- Theodore Dubois <tblodt@icloud.com>
- Saagar Jha <saagar@saagarjha.com>
- Christoffer Tønnessen <christoffertonnessen@icloud.com> <christoffer.tonnessen@gmail.com>
- Philipp Wallisch <philipp.wallisch@inode.at>
- Ed Luff <beartechtalks@gmail.com>
- David Southgate <d@davidsouthgate.co.uk>
- Charlie Melbye <charles.melbye@gmail.com>
- David <0b101@users.noreply.github.com>
- [as@irc](https://gist.github.com/tbodt/45ccbea8d3c095258d63f611654f05b4)
- asdfugil (name was "Assfugil" when last contributed) <towinchenmi@gmail.com> <42699250+Assfugil@users.noreply.github.com>
- AngeloHYang <38714377+AngeloHYang@users.noreply.github.com>
- Matthew Merrill <mattmerr47@gmail.com>
- Siddharth Dushantha <siddharth.dushantha@gmail.com>
- Lorenzo De Linares <lorenzo.linares@icloud.com>
- Christopher Albert <albert@alumni.tugraz.at>
- Stephen Leaf <stephenaleaf@gmail.com>
- Noah Peeters <noah@noahpeeters.de>
- Alexis Marquis <alexis@marquis.me>
- Brian Almeida <bma@thunderkeys.net>
- Viktor Oreshkin <imselfish@stek29.rocks>
- Ryan Hileman <lunixbochs@gmail.com>
- Christoforos Charalambous <chrischaralambous14@gmail.com>
- Kenta Kubo <kabuto669@icloud.com>
- Zhuowei Zhang
- never_released <24752637+woachk@users.noreply.github.com>

[GPLv3]: https://www.gnu.org/licenses/gpl-3.0.html
[GPLv2]: https://www.gnu.org/licenses/old-licenses/gpl-2.0.html
