#import <UIKit/UIKit.h>

@interface TSSceneDelegate : UIResponder <UIWindowSceneDelegate>
@property (strong, nonatomic) UIWindow * window;
@property (nonatomic, strong) UITabBarController *rootViewController;
@end
