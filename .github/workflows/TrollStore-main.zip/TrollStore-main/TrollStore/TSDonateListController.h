#import <Preferences/PSListController.h>

@interface TSDonateListController : PSListController

@end