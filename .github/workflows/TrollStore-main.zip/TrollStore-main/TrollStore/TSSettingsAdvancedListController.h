#import <Preferences/PSListController.h>

@interface TSSettingsAdvancedListController : PSListController

@end