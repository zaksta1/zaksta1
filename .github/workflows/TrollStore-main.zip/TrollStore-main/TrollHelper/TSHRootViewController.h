#import <TSListControllerShared.h>

@interface TSHRootViewController : TSListControllerShared
{
    NSString* _newerVersion;
}
@end
